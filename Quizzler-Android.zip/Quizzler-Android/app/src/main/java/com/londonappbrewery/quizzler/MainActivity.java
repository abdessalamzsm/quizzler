package com.londonappbrewery.quizzler;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    
    // TODO: Declare member variables here:

    private SoundPool mSoundPool;
    private int soundWinner;

    private Button True;
    private Button False;
    private TextView Question;
    private TextView Score;
    private ProgressBar Progress;
    private int index = 0;
    private int score=0;

    private TextView Ques;


    // TODO: Uncomment to create question bank
    private TrueFalse[] mQuestionBank = new TrueFalse[] {
            new TrueFalse(R.string.question_1, true),
            new TrueFalse(R.string.question_2, true),
            new TrueFalse(R.string.question_3, true),
            new TrueFalse(R.string.question_4, true),
            new TrueFalse(R.string.question_5, true),
            new TrueFalse(R.string.question_6, false),
            new TrueFalse(R.string.question_7, true),
            new TrueFalse(R.string.question_8, false),
            new TrueFalse(R.string.question_9, true),
            new TrueFalse(R.string.question_10, true),
            new TrueFalse(R.string.question_11, false),
            new TrueFalse(R.string.question_12, false),
             new TrueFalse(R.string.question_13,true)
    };

    // TODO: Declare constants here


    final  int Progress_increment= (int) Math.ceil(100.0 / mQuestionBank.length);
    
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        True  = findViewById(R.id.true_button);
        False = findViewById(R.id.false_button);
        Question = findViewById(R.id.question);
        Score = findViewById(R.id.score);
        Progress = findViewById(R.id.progress_bar);
        Ques = findViewById(R.id.Ques);

        mSoundPool = new SoundPool(1, AudioManager.STREAM_MUSIC,1);
        soundWinner = mSoundPool.load(getApplicationContext(),R.raw.win,1);

        Ques.setText("Question 1/"+mQuestionBank.length);

        Question.setText(mQuestionBank[index].getQuestion());

        View.OnClickListener listener= new View.OnClickListener(){

            @Override
            public void onClick(View view) {

               Check(true);
            }
        };
        True.setOnClickListener(listener);
        False.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Check(false);
            }
        });

    }
    private void NextQuestion()
    {
        index = (index+1)%mQuestionBank.length;



        if(index==0)
        {


            if(score > mQuestionBank.length/2)
            {
                mSoundPool.play(soundWinner,1,1,0,0,1);
            }

            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Finished")
                    .setMessage("Your Score is "+score+"/"+mQuestionBank.length)
                    .setCancelable(false)
                    .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
            alert.show();
        }
        Question.setText(mQuestionBank[index].getQuestion());
        Ques.setText("Question "+(index+1)+"/"+mQuestionBank.length);
        Progress.incrementProgressBy(Progress_increment );
    }

    private void Check(Boolean b)
    {
        boolean Correction = mQuestionBank[index].isAnswer();
        if(b == Correction)
        {
            Toast.makeText(MainActivity.this,R.string.correct_toast,Toast.LENGTH_SHORT).show();
            score++;
            Score.setText("Score"+score+"/"+mQuestionBank.length);
            NextQuestion();
        }
        else
        {
            Toast.makeText(MainActivity.this,R.string.incorrect_toast,Toast.LENGTH_SHORT).show();
            NextQuestion();
        }
    }
}
